<?php

//print_r($_SERVER);die();

$sitepad['db_name'] = 'cvgizyxi_spad350';
$sitepad['db_user'] = 'cvgizyxi_spad350';
$sitepad['db_pass'] = 'OP!gKV8C[)';
$sitepad['db_host'] = 'localhost';
$sitepad['db_table_prefix'] = 'cx7qJ1V_';
$sitepad['charset'] = 'utf8mb4';
$sitepad['collate'] = 'utf8mb4_unicode_ci';
$sitepad['serving_url'] = 'easykiller.in/new';// URL without protocol but with directory as well
$sitepad['url'] = 'https://easykiller.in/new';
$sitepad['relativeurl'] = '/new';
$sitepad['.sitepad'] = '/home/cvgizyxi';
$sitepad['sitepad_plugin_path'] = '/usr/local/sitepad';
$sitepad['editor_path'] = '/usr/local/sitepad/editor';
$sitepad['path'] = dirname(__FILE__);
$sitepad['AUTH_KEY'] = 'h0ikHcdDgLmEe8YqokPf4lPfj5yyeN1998XtgnPXpj1DvLvoOw2EnuDA0S9ssABe';
$sitepad['SECURE_AUTH_KEY'] = 'AkEExWfzBlOWxUrxhIn0GBetScnBE0PDViBv88Srvh8wUiFSahgXSioOSWju9tPV';
$sitepad['LOGGED_IN_KEY'] = '0nVDTaCjrrPv737yQZSO9yOPikcsyBYepVYNR5fqncW3KesghsA7MQkSNaRgIBWH';
$sitepad['NONCE_KEY'] = 'BJwNPEkqOJN3oogXpVeuskOxCAIQZ4YOcGR8ayduKlR9KGml7WNqBup3ZG4s3ZBM';
$sitepad['AUTH_SALT'] = '4nQLFXD3lKbKbW1KEvowQH65FKFtLPRs3klX7CBP3tobjkhSU0GX1mweqPLXyMEC';
$sitepad['SECURE_AUTH_SALT'] = 'Pws2ZyYMblK6JCYMMkyNlwUeKMWszKqCQYrOGxu41qs3HyPBWQRbsDhiTIw9fcTV';
$sitepad['LOGGED_IN_SALT'] = 'uKt6OQqVCkBkpLofBoDAJHfFtrIXIdVysHLGBTjiO3nVjZaSXEtt1LylGjRPai5i';
$sitepad['NONCE_SALT'] = 'vKBFor6y0Cg0ggwRhLze2Gw9no83uCJGcKLcWCmFDwogx6A2W05NJgbCmB7AiveA';

if(!include_once($sitepad['editor_path'].'/site-inc/bootstrap.php')){
	die('Could not include the bootstrap.php. One of the reasons could be open_basedir restriction !');
}

